<!--Boostrap style sheet-->
<link href="../css/base.css" type="text/css" rel="stylesheet">
		
<!--Global style sheet-->
<link href="../css/base.css" type="text/css" rel="stylesheet">