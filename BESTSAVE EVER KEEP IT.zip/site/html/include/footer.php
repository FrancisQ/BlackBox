<!--Footer -->
<div id="main-footer">
	<div id="nav-footer" class="imgCent">
		<!-- <embed src="../music/theme.mp3" autostart="false" loop="true"> -->
		<img src="../img/fabse.png" alt="Fabse Games" id="fabseImg">
	</div>
</div>
